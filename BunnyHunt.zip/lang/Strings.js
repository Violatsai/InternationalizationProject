var i18n = {
    'The Good Friday Massacre': '復活節大屠殺',
    'Bunny': '獵殺',
    'Hunt IV': '兔兔',
    'let\'s shoot some bunnies!': '一起獵殺兔兔吧！',
    'Number of bunnies splattered': '殲滅兔兔數量',
    'Number of bunnies eviscerated': '剿滅兔兔數量',
    'Number of bunnies mutilated': '消滅兔兔數量',
    'Number of bunnies massacred': '幹掉兔兔數量',
    'Number of bunnies butchered': '做掉兔兔數量',
    'Level ': '等級 ',
    'reload your shotgun!': '再來一次！',
    'make the killing stop!': '放過兔兔吧！',
    'The bunnies of the world thank you for your pacifism. Happy Easter!': '兔兔感謝你的大恩大德，復活節快樂！'
};